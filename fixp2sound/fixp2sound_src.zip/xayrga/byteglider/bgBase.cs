﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xayrga.byteglider
{
  public enum BGAlignDirection
    {
        FORWARD = 0,
        REVERSE = 1,
    }
}
